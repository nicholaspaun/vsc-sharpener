open System

module <%= namespace %> =
    let t = 1