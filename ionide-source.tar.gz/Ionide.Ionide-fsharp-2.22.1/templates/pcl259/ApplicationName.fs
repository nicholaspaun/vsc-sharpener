﻿namespace <%= namespace %>

type <%= namespace %>() =
    member this.X = "F#"
