"use strict";

exports.__esModule = true;
exports.msbuild = exports.fsi = exports.isWin = undefined;

var _fs = require("fs");

var fs = _interopRequireWildcard(_fs);

var _fableCore = require("fable-core");

var _vscode = require("vscode");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var isWin = exports.isWin = process.platform === "win32";

function op_LessDivideGreater(a, b) {
    return isWin ? a + "\\" + b : a + "/" + b;
}

function dirExists(dir) {
    try {
        return fs.statSync(dir).isDirectory();
    } catch (matchValue) {
        return false;
    }
}

function fileExists(file) {
    try {
        return fs.statSync(file).isFile();
    } catch (matchValue) {
        return false;
    }
}

function getOrElse(defaultValue, option) {
    return option != null ? option : defaultValue;
}

var programFilesX86 = function () {
    var wow64 = process.env.PROCESSOR_ARCHITEW6432;
    var globalArch = process.env.PROCESSOR_ARCHITECTURE;
    return function (detected) {
        return detected == null ? "C:\\Program Files (x86)\\" : detected;
    }(function () {
        var matchValue = [wow64, globalArch];

        var $target0 = function $target0() {
            return process.env["ProgramFiles(x86)"];
        };

        var $target1 = function $target1() {
            return process.env.ProgramFiles;
        };

        if (matchValue[0] === "AMD64") {
            if (matchValue[1] === "AMD64") {
                return $target0();
            } else {
                return $target1();
            }
        } else {
            if (matchValue[0] === "x86") {
                if (matchValue[0] == null) {
                    if (matchValue[1] === "AMD64") {
                        return $target0();
                    } else {
                        return $target1();
                    }
                } else {
                    if (matchValue[1] === "AMD64") {
                        return $target0();
                    } else {
                        return $target1();
                    }
                }
            } else {
                if (matchValue[0] == null) {
                    if (matchValue[1] === "AMD64") {
                        return $target0();
                    } else {
                        return $target1();
                    }
                } else {
                    return $target1();
                }
            }
        }
    }());
}();

function getToolsPathWindows() {
    return function (list) {
        return _fableCore.Seq.tryFind(function (dir) {
            return dirExists(dir);
        }, list);
    }(_fableCore.List.map(function (v) {
        return op_LessDivideGreater(op_LessDivideGreater(op_LessDivideGreater(programFilesX86, "\\Microsoft SDKs\\F#\\"), v), "\\Framework\\v4.0");
    }, _fableCore.List.ofArray(["4.0", "3.1", "3.0"])));
}

function getToolsPathFromConfiguration() {
    var cfg = _vscode.workspace.getConfiguration();

    var path = cfg.get("FSharp.toolsDirPath", "");

    if (!(path === "") ? dirExists(path) : false) {
        return path;
    }
}

function getListDirectoriesToSearchForTools() {
    return _fableCore.List.choose(function (x) {
        return x;
    }, isWin ? _fableCore.List.ofArray([getToolsPathFromConfiguration(), getToolsPathWindows()]) : _fableCore.List.ofArray([getToolsPathFromConfiguration()]));
}

function findFirstValidFilePath(exeName, directoryList) {
    return function (list) {
        return _fableCore.Seq.tryFind(function (file) {
            return fileExists(file);
        }, list);
    }(_fableCore.List.map(function (v) {
        return op_LessDivideGreater(v, exeName);
    }, directoryList));
}

function getFsiFilePath() {
    return isWin ? function () {
        var cfg = _vscode.workspace.getConfiguration();

        var fsiPath = cfg.get("FSharp.fsiFilePath", "");

        if (fsiPath === "") {
            return "FsiAnyCpu.exe";
        } else {
            return fsiPath;
        }
    }() : "fsharpi";
}

var fsi = exports.fsi = function () {
    var fileName = getFsiFilePath();
    var dirs = getListDirectoriesToSearchForTools();
    var matchValue = findFirstValidFilePath(fileName, dirs);

    if (matchValue != null) {
        return matchValue;
    } else {
        return fileName;
    }
}();

var msbuild = exports.msbuild = !isWin ? "xbuild" : function () {
    var MSBuildPath = _fableCore.List.ofArray([op_LessDivideGreater(programFilesX86, "\\MSBuild\\14.0\\Bin"), op_LessDivideGreater(programFilesX86, "\\MSBuild\\12.0\\Bin"), op_LessDivideGreater(programFilesX86, "\\MSBuild\\12.0\\Bin\\amd64"), "c:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\", "c:\\Windows\\Microsoft.NET\\Framework\\v4.0.30128\\", "c:\\Windows\\Microsoft.NET\\Framework\\v3.5\\"]);

    return findFirstValidFilePath("MSBuild.exe", MSBuildPath);
}();
//# sourceMappingURL=Environment.js.map